package Color::Transform;
use 5.012;
use warnings;
use overload '""' => 'to_string';

# :squash-remove-start:
require Color;
# :squash-remove-end:

sub new {
    my $class = shift;
    return bless {
        actions => [],
    }, $class;
}

sub new_from_colors {
    my ($class, $from, $to) = @_;

    $from //= Color->new;

    my $self = __PACKAGE__->new;

    # XXX if we unset bold or underline, we have to set our color again because
    # unsetting underline involves resetting the color
    if (
        $from->{bold} != $to->{bold}
        && !$to->{bold}
        || $from->{underline} != $to->{underline}
        && !$to->{underline}
    ) {
        $self->with_reset;
        $from = Color->new(
            mode => $from->{mode},
        );
    }

    if ($from->{bold} != $to->{bold}) {
        $self->bold;
    }

    if ($from->{underline} != $to->{underline}) {
        $self->underline;
    }

    if ($from->{fg} != $to->{fg}) {
        $self->fg($to->{fg});
    }

    if ($from->{bg} != $to->{bg}) {
        $self->bg($to->{bg});
    }

    if ($from->{mode} ne $to->{mode}) {
        $self->mode($to->{mode});
    }

    return $self;
}

sub with_reset {
    my $self = shift;
    if (@{$self->{actions}} < 1 || $self->{actions}->[0] != 0) {
        unshift @{$self->{actions}}, 0;
    }
    return $self;
}

sub bold {
    my $self = shift;
    $self->_push(1);
    return;
}

sub underline {
    # TODO this is right in uxterm, but wrong in xterm. \e[4;37m works, though.
    my $self = shift;
    $self->_push(4);
    return;
}

sub fg {
    my ($self, $fg) = @_;
    if ($fg < 8) {
        $self->_push($fg + 30);
    } elsif ($fg < 16) {
        $self->_push($fg + 82);
    } else {
        $self->_push(38, 5, $fg);
    }
    return;
}

sub bg {
    my ($self, $bg) = @_;
    if ($bg < 8) {
        $self->_push($bg + 40);
    } elsif ($bg < 16) {
        $self->_push($bg + 92);
    } else {
        $self->_push(48, 5, $bg);
    }
    return;
}

sub mode {
    my ($self, $mode) = @_;
    if ($mode eq 'G1') {
        $self->{after} = '\\016';
    } else {
        # Normal
        $self->{after} = '\\017';
    }
    return;
}

sub _push {
    my ($self, @actions) = @_;
    push @{$self->{actions}}, @actions;
    return;
}

sub to_string {
    my $self = shift;
    my $out = '';
    # See https://no-color.org/
    unless (defined $ENV{NO_COLOR}) {
        if (@{$self->{actions}}) {
            $out .= sprintf '\\e[%sm',
                (join ';', @{$self->{actions}}),
        }
    }
    # XXX Should still print box drawing enable/disable even if colors are
    # disabled.
    $out .= $self->{after} // '';
    return $out;
}

=head1 AUTHOR

Dan Church S<E<lt>h3xx@gmx.comE<gt>>

=head1 COPYRIGHT

Copyright (C) 2020-2022 Dan Church.

License GPLv3: GNU GPL version 3.0 (L<https://www.gnu.org/licenses/gpl-3.0.html>)
with Commons Clause 1.0 (L<https://commonsclause.com/>).
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.
You may NOT use this software for commercial purposes.

=cut

1;

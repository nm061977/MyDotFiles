TODO
====

- Can't set a "bold" 16-color background.


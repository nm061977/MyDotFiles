#!/bin/bash
WORKDIR=$(dirname -- "$0")
OUT=$WORKDIR/promptgen.pl

echo "Outputting to $OUT" >&2

shopt -s globstar
"$WORKDIR/util/perl-squasher/squash" \
    "$WORKDIR/promptgen-main.pl" \
    "$WORKDIR"/lib/**/*.pm \
    > "$OUT"
chmod +x -- "$OUT"

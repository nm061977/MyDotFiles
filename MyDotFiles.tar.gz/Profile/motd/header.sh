# Simple static header for update-motd framework

COLOR_GREEN="\033[0;32m"
 
# print personal static banner in green
printf "${COLOR_GREEN}
  _____ .__         .__     .__ 
_/ ____\|__|  ______|  |__  |__|
\   __\ |  | /  ___/|  |  \ |  |
 |  |   |  | \___ \ |   Y  \|  |
 |__|   |__|/____  >|___|  /|__|
                 \/      \/     
 
Debian GNU/Linux 7.x\n\n" 
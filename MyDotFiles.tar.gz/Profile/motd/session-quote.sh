# Simple dynamic quote header for update-motd framework

COLOR_BLUE="\033[01;34m"
COLOR_DEFAULT="\033[0m"
 
# print a random session quote
printf "${COLOR_BLUE}Session Quote:\n" 
/usr/games/fortune 100% computers | /usr/games/cowsay -f tux
 
# reset color to terminal default
printf "${COLOR_DEFAULT}\n"
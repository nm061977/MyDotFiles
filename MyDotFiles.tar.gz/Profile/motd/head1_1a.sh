#!/bin/bash
skull() {
W="\e[0;39m"
R="\e[1;31m"
G="\e[1;32m"
C="\e[1;36m"
B="\e[1;34m"
Y="\e[1;33m"
clear
#sleep 2
echo -e "             ${W}..ooo@@@XXX%%%xx.."
echo -e "          ${W}.oo@@XXX%x%xxx..      ."
echo -e "        ""${W}"".o@XX%%xx..               ."
echo -e "      ${W}o@X%..                  ..ooooooo"
echo -e "    ${W}.@X%x.                 ..o@@^^   ^^@@o"
echo -e "  ${W}.ooo@@@@@@ooo..      ..o@@^          @X%"
echo -e "  ${W}o@@^^^     ^^^@@@ooo.oo@@^             %"
echo -e " ${W}xzI   ${Y}-${R}*${Y}--      ${W}^^^o^^        ${Y}--${R}*${Y}-     ${W}%"
echo -e " ${W}@@@o     ooooooo^@@^o^@X^@oooooo     .X%x"
echo -e "${W}I@@@@@@@@@XX%%xx  ( ${G}o@o${W} )X%x@ROMBASED@@@X%x"
echo -e "${W}I@@@@XX%%xx  oo@@@@X% @@X%x   ^^^@@@@@@@X%x"
echo -e " ${W}@X%xx     o@@@@@@@X% @@XX%%x  )    ^^@X%x"
echo -e "  ${W}^   xx o@@@@@@@@Xx  ^ @XX%%x    xxx"
echo -e "        ${W}o@@^^^ooo I^^ I^o ooo   .  x"
echo -e "        ${W}oo @^ IX      I   ^X  @^ oo"
echo -e "        ${W}IX     U  .        V     IX"
echo -e "         ${W}V     .           .     V"
echo ""
echo -e "${B}Today's Date:      ${C}$(date +%d-%m-%Y)${W}"; }
skull
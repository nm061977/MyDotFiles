#!/bin/bash
########################################################
#  Written by r00t_Gh0sT
#       $NOW
########################################################
#!/bin/bash
W="\e[0;39m" # White
R="\e[1;31m" # Red
G="\e[1;32m" # Green
C="\e[1;36m" # Cyan
B="\e[1;34m" # Blue
Y="\e[1;33m" # Yellow


printf "             ${W}..ooo@@@XXX%%%xx.."
printf "          ${W}.oo@@XXX%x%xxx..     ` ."
printf "        ${W}.o@XX%%xx..               ` ."
printf "      ${W}o@X%..                  ..ooooooo"
printf "    ${W}.@X%x.                 ..o@@^^   ^^@@o"
printf "  ${W}.ooo@@@@@@ooo..      ..o@@^          @X%"
printf "  ${W}o@@^^^     ^^^@@@ooo.oo@@^             %"
printf " ${W}xzI   ${Y}-${R}*${Y}--      ${W}^^^o^^        ${Y}--${R}*${Y}-     ${W}%"
printf " ${W}@@@o     ooooooo^@@^o^@X^@oooooo     .X%x"
printf "${W}I@@@@@@@@@XX%%xx  ( o@o )X%x@ROMBASED@@@X%x"
printf "${W}I@@@@XX%%xx  oo@@@@X% @@X%x   ^^^@@@@@@@X%x"
printf " ${W}@X%xx     o@@@@@@@X% @@XX%%x  )    ^^@X%x"
printf "  ${W}^   xx o@@@@@@@@Xx  ^ @XX%%x    xxx"
printf "        ${W}o@@^^^ooo I^^ I^o ooo   .  x"
printf "        ${W}oo @^ IX      I   ^X  @^ oo"
printf "        ${W}IX     U  .        V     IX"
printf "         ${W}V     .           .     V"             ${W}..ooo@@@XXX%%%xx..
          ${W}.oo@@XXX%x%xxx..     ` .
        ${W}.o@XX%%xx..               ` .
      ${W}o@X%..                  ..ooooooo
    ${W}.@X%x.                 ..o@@^^   ^^@@o
  ${W}.ooo@@@@@@ooo..      ..o@@^          @X%
  ${W}o@@^^^     ^^^@@@ooo.oo@@^             %
 ${W}xzI   ${Y}-${R}*${Y}--      ${W}^^^o^^        ${Y}--${R}*${Y}-     ${W}%
 ${W}@@@o     ooooooo^@@^o^@X^@oooooo     .X%x
${W}I@@@@@@@@@XX%%xx  ( o@o )X%x@ROMBASED@@@X%x
${W}I@@@@XX%%xx  oo@@@@X% @@X%x   ^^^@@@@@@@X%x
 ${W}@X%xx     o@@@@@@@X% @@XX%%x  )    ^^@X%x
  ${W}^   xx o@@@@@@@@Xx  ^ @XX%%x    xxx
        ${W}o@@^^^ooo I^^ I^o ooo   .  x
        ${W}oo @^ IX      I   ^X  @^ oo
        ${W}IX     U  .        V     IX
         ${W}V     .           .     V
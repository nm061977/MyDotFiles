#!/bin/bash
W="\e[0;39m"
R="\e[1;31m"
G="\e[1;32m"
C="\e[1;36m"
B="\e[1;34m"
Y="\e[1;33m"
clear
sleep 2
echo -e "             ..ooo@@@XXX%%%xx.."
echo -e "          .oo@@XXX%x%xxx..     ` ."
echo -e "        .o@XX%%xx..               ` ."
echo -e "      o@X%..                  ..ooooooo"
echo -e "    .@X%x.                 ..o@@^^   ^^@@o"
echo -e "  .ooo@@@@@@ooo..      ..o@@^          @X%"
echo -e "  o@@^^^     ^^^@@@ooo.oo@@^             %"
echo -e " xzI    -*--      ^^^o^^        --*-     %"
echo -e " @@@o     ooooooo^@@^o^@X^@oooooo     .X%x"
echo -e "I@@@@@@@@@XX%%xx  ( o@o )X%x@ROMBASED@@@X%x"
echo -e "I@@@@XX%%xx  oo@@@@X% @@X%x   ^^^@@@@@@@X%x"
echo -e " @X%xx     o@@@@@@@X% @@XX%%x  )    ^^@X%x"
echo -e "  ^   xx o@@@@@@@@Xx  ^ @XX%%x    xxx"
echo -e "        o@@^^^ooo I^^ I^o ooo   .  x"
echo -e "        oo @^ IX      I   ^X  @^ oo"
echo -e "        IX     U  .        V     IX"
echo -e "         V     .           .     V"
sleep 5


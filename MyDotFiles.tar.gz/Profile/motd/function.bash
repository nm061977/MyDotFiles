function new_script() {
    NOW=$(date +%d-%m-%Y)
    cat << "EOF" > $1
    #!/bin/bash\n
    #  Written by r00t_Gh0sT\n
    #       $NOW\n
    ########################################################\n
    EOF
    fi;
}




#!/bin/bash

function new_script {
if true;
then
        cat <<- "END"
        Hello
        World
END
fi
}